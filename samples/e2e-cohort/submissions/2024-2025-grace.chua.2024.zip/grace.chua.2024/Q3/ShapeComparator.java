/*
 * Name: Grace Chua
 * Email ID: grace.chua.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    // bigger area first, then bigger perimeter first
    public int compare(Shape x1, Shape token) {
        double diff = token.getArea() - x1.getArea();
        if (diff == 0) {
            diff = token.getPerimeter() - x1.getPerimeter();
        }
        if (diff > 0) {
            return 1;
        } else if (diff < 0) {
            return -1;
        }
        return 0;
    }
}
