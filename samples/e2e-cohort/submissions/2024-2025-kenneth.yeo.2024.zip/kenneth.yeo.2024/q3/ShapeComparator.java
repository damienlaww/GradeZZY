/*
 * Name: Kenneth Yeo
 * Email ID: kenneth.yeo.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    public int compare(Shape sa, Shape elem) {
        int byArea = Double.compare(elem.getArea(), sa.getArea());
        if (byArea != 0) {
            return byArea;
        }
        return Double.compare(elem.getPerimeter(), sa.getPerimeter());
    }
}
