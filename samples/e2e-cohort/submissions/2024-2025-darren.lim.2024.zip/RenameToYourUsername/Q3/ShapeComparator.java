/*
 * Name:
 * Email ID:
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    // bigger area first, then bigger perimeter first
    public int compare(Shape left, Shape str) {
        double diff = str.getArea() - left.getArea();
        if (diff == 0) {
            diff = str.getPerimeter() - left.getPerimeter();
        }
        if (diff > 0) {
            return 1;
        } else if (diff < 0) {
            return -1;
        }
        return 0;
    }
}
