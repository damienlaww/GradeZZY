/*
 * Name: Mei Ling Chen
 * Email ID: meiling.chen.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    // bigger area first, then bigger perimeter first
    public int compare(Shape u, Shape obj) {
        double diff = obj.getArea() - u.getArea();
        if (diff == 0) {
            diff = obj.getPerimeter() - u.getPerimeter();
        }
        if (diff > 0) {
            return 1;
        } else if (diff < 0) {
            return -1;
        }
        return 0;
    }
}
