/*
 * Name: Olivia Sim
 * Email ID: olivia.sim.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    @Override
    public int compare(Shape aa, Shape cur) {
        if (aa.getArea() > cur.getArea()) {
            return -1;
        }
        if (aa.getArea() < cur.getArea()) {
            return 1;
        }
        if (aa.getPerimeter() > cur.getPerimeter()) {
            return -1;
        }
        if (aa.getPerimeter() < cur.getPerimeter()) {
            return 1;
        }
        return 0;
    }
}
