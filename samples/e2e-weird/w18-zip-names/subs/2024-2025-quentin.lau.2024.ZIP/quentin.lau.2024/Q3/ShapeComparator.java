/*
 * Name: Quentin Lau
 * Email ID: quentin.lau.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    public int compare(Shape shp1, Shape el) {
        int byArea = Double.compare(el.getArea(), shp1.getArea());
        if (byArea != 0) {
            return byArea;
        }
        return Double.compare(el.getPerimeter(), shp1.getPerimeter());
    }
}
