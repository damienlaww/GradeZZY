/*
 * Name: Hui Min Lee
 * Email ID: huimin.lee.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    public int compare(Shape lhs, Shape entry) {
        int byArea = Double.compare(entry.getArea(), lhs.getArea());
        if (byArea != 0) {
            return byArea;
        }
        return Double.compare(entry.getPerimeter(), lhs.getPerimeter());
    }
}
