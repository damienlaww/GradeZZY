/*
 * Name: Mei Ling Ho
 * Email ID: meiling.ho.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    public int compare(Shape x13, Shape token3) {
        int byArea = Double.compare(token3.getArea(), x13.getArea());
        if (byArea != 0) {
            return byArea;
        }
        return Double.compare(token3.getPerimeter(), x13.getPerimeter());
    }
}
