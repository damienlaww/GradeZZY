/*
 * Name: Lakshmi Raj
 * Email ID: lakshmi.raj.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    public int compare(Shape f, Shape thing) {
        int byArea = Double.compare(thing.getArea(), f.getArea());
        if (byArea != 0) {
            return byArea;
        }
        return Double.compare(thing.getPerimeter(), f.getPerimeter());
    }
}
