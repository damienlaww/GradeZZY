/*
 * Name: Victor Low
 * Email ID: visitor.g2.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    public int compare(Shape o13, Shape x3) {
        int byArea = Double.compare(x3.getArea(), o13.getArea());
        if (byArea != 0) {
            return byArea;
        }
        return Double.compare(x3.getPerimeter(), o13.getPerimeter());
    }
}
