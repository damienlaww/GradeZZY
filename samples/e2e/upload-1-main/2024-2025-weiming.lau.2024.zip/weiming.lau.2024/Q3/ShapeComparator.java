/*
 * Name: Wei Ming, Alvin Lau
 * Email ID: weiming.lau.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    public int compare(Shape first3, Shape word3) {
        int byArea = Double.compare(word3.getArea(), first3.getArea());
        if (byArea != 0) {
            return byArea;
        }
        return Double.compare(word3.getPerimeter(), first3.getPerimeter());
    }
}
