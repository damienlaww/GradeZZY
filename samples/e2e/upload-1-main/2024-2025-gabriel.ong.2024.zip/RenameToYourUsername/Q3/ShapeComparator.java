/*
 * Name:
 * Email ID:
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    @Override
    public int compare(Shape p, Shape candidate) {
        if (p.getArea() > candidate.getArea()) {
            return -1;
        }
        if (p.getArea() < candidate.getArea()) {
            return 1;
        }
        if (p.getPerimeter() > candidate.getPerimeter()) {
            return -1;
        }
        if (p.getPerimeter() < candidate.getPerimeter()) {
            return 1;
        }
        return 0;
    }
}
