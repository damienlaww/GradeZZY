/*
 * Name: Samuel Chan
 * Email ID: samuel.chan.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    @Override
    public int compare(Shape left2, Shape str2) {
        if (left2.getArea() > str2.getArea()) {
            return -1;
        }
        if (left2.getArea() < str2.getArea()) {
            return 1;
        }
        if (left2.getPerimeter() > str2.getPerimeter()) {
            return -1;
        }
        if (left2.getPerimeter() < str2.getPerimeter()) {
            return 1;
        }
        return 0;
    }
}
