/*
 * Name: Benjamin Koh
 * Email ID: benjamin.koh.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    @Override
    public int compare(Shape s1x, Shape s) {
        if (s1x.getArea() > s.getArea()) {
            return -1;
        }
        if (s1x.getArea() < s.getArea()) {
            return 1;
        }
        if (s1x.getPerimeter() > s.getPerimeter()) {
            return -1;
        }
        if (s1x.getPerimeter() < s.getPerimeter()) {
            return 1;
        }
        return 0;
    }
}
