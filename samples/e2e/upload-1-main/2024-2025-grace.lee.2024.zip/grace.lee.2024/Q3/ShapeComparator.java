/*
 * Name: Grace Lee
 * Email ID: grace.lee.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    @Override
    public int compare(Shape one3, Shape current3) {
        if (one3.getArea() > current3.getArea()) {
            return -1;
        }
        if (one3.getArea() < current3.getArea()) {
            return 1;
        }
        if (one3.getPerimeter() > current3.getPerimeter()) {
            return -1;
        }
        if (one3.getPerimeter() < current3.getPerimeter()) {
            return 1;
        }
        return 0;
    }
}
