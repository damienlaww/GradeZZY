/*
 * Name: Qi Hao Zhang
 * Email ID: qihao.zhang.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    // bigger area first, then bigger perimeter first
    public int compare(Shape a2, Shape w2) {
        double diff = w2.getArea() - a2.getArea();
        if (diff == 0) {
            diff = w2.getPerimeter() - a2.getPerimeter();
        }
        if (diff > 0) {
            return 1;
        } else if (diff < 0) {
            return -1;
        }
        return 0;
    }
}
