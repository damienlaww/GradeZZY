/*
 * Name: Jia Hui Lim
 * Email ID: jiahui.lim.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    @Override
    public int compare(Shape m, Shape value2) {
        if (m.getArea() > value2.getArea()) {
            return -1;
        }
        if (m.getArea() < value2.getArea()) {
            return 1;
        }
        if (m.getPerimeter() > value2.getPerimeter()) {
            return -1;
        }
        if (m.getPerimeter() < value2.getPerimeter()) {
            return 1;
        }
        return 0;
    }
}
