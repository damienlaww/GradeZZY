/*
 * Name: Darius Tan
 * Email ID: darius.tan.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    public int compare(Shape s1, Shape s2) {
        if (s1.getArea() > s2.getArea()) {
            return -1;
        } else if (s1.getArea() < s2.getArea()) {
            return 1;
        }
        return 0;
    }
}
