﻿/*
 * Name: Shu Ting Wee
 * Email ID: shuting.wee.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    // bigger area first, then bigger perimeter first
    public int compare(Shape one2, Shape current2) {
        double diff = current2.getArea() - one2.getArea();
        if (diff == 0) {
            diff = current2.getPerimeter() - one2.getPerimeter();
        }
        if (diff > 0) {
            return 1;
        } else if (diff < 0) {
            return -1;
        }
        return 0;
    }
}
