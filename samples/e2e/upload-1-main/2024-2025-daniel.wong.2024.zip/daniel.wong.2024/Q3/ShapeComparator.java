/*
 * Name: Daniel Wong
 * Email ID: daniel.wong.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    public int compare(Shape one, Shape current) {
        int byArea = Double.compare(current.getArea(), one.getArea());
        if (byArea != 0) {
            return byArea;
        }
        return Double.compare(current.getPerimeter(), one.getPerimeter());
    }
}
