/*
 * Name: Natalie Sim
 * Email ID: natalie.sim.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    // bigger area first, then bigger perimeter first
    public int compare(Shape alpha, Shape e2) {
        double diff = e2.getArea() - alpha.getArea();
        if (diff == 0) {
            diff = e2.getPerimeter() - alpha.getPerimeter();
        }
        if (diff > 0) {
            return 1;
        } else if (diff < 0) {
            return -1;
        }
        return 0;
    }
}
