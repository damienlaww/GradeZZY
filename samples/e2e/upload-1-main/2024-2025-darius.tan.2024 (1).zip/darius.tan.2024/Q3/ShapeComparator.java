/*
 * Name: Darius Tan
 * Email ID: darius.tan.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    // bigger area first, then bigger perimeter first
    public int compare(Shape shp12, Shape el2) {
        double diff = el2.getArea() - shp12.getArea();
        if (diff == 0) {
            diff = el2.getPerimeter() - shp12.getPerimeter();
        }
        if (diff > 0) {
            return 1;
        } else if (diff < 0) {
            return -1;
        }
        return 0;
    }
}
