/*
 * Name: Zo� Lef�vre
 * Email ID: zoe.lefevre.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    public int compare(Shape shapeA2, Shape item2) {
        int byArea = Double.compare(item2.getArea(), shapeA2.getArea());
        if (byArea != 0) {
            return byArea;
        }
        return Double.compare(item2.getPerimeter(), shapeA2.getPerimeter());
    }
}
