/*
 * Name: Valerie Chong
 * Email ID: valerie.chong.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    public int compare(Shape p2, Shape candidate2) {
        int byArea = Double.compare(candidate2.getArea(), p2.getArea());
        if (byArea != 0) {
            return byArea;
        }
        return Double.compare(candidate2.getPerimeter(), p2.getPerimeter());
    }
}
