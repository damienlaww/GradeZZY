/*
 * Name: Cheryl Foo
 * Email ID: cheryl.foo.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    @Override
    public int compare(Shape alpha2, Shape e22) {
        if (alpha2.getArea() > e22.getArea()) {
            return -1;
        }
        if (alpha2.getArea() < e22.getArea()) {
            return 1;
        }
        if (alpha2.getPerimeter() > e22.getPerimeter()) {
            return -1;
        }
        if (alpha2.getPerimeter() < e22.getPerimeter()) {
            return 1;
        }
        return 0;
    }
}
