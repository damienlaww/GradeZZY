/*
 * Name: Rachel Lim
 * Email ID: rachel.lim.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    public int compare(Shape s1x2, Shape s2) {
        int byArea = Double.compare(s2.getArea(), s1x2.getArea());
        if (byArea != 0) {
            return byArea;
        }
        return Double.compare(s2.getPerimeter(), s1x2.getPerimeter());
    }
}
