/*
 * Name: Jun Wei Tan
 * Email ID: junwei.tan.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    @Override
    public int compare(Shape a3, Shape w3) {
        if (a3.getArea() > w3.getArea()) {
            return -1;
        }
        if (a3.getArea() < w3.getArea()) {
            return 1;
        }
        if (a3.getPerimeter() > w3.getPerimeter()) {
            return -1;
        }
        if (a3.getPerimeter() < w3.getPerimeter()) {
            return 1;
        }
        return 0;
    }
}
