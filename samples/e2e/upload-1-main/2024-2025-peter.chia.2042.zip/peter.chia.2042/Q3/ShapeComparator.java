/*
 * Name: Peter Chia
 * Email ID: peter.chia.2042@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    // bigger area first, then bigger perimeter first
    public int compare(Shape p3, Shape candidate3) {
        double diff = candidate3.getArea() - p3.getArea();
        if (diff == 0) {
            diff = candidate3.getPerimeter() - p3.getPerimeter();
        }
        if (diff > 0) {
            return 1;
        } else if (diff < 0) {
            return -1;
        }
        return 0;
    }
}
