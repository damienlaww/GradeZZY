/*
 * Name: Zhi Wei Koh
 * Email ID: zhiwei.koh.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    // bigger area first, then bigger perimeter first
    public int compare(Shape f2, Shape thing2) {
        double diff = thing2.getArea() - f2.getArea();
        if (diff == 0) {
            diff = thing2.getPerimeter() - f2.getPerimeter();
        }
        if (diff > 0) {
            return 1;
        } else if (diff < 0) {
            return -1;
        }
        return 0;
    }
}
