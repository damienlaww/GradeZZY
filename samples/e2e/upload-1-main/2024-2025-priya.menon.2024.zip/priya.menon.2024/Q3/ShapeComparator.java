/*
 * Name: Priya Menon
 * Email ID: priya.menon.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    @Override
    public int compare(Shape first2, Shape word2) {
        if (first2.getArea() > word2.getArea()) {
            return -1;
        }
        if (first2.getArea() < word2.getArea()) {
            return 1;
        }
        if (first2.getPerimeter() > word2.getPerimeter()) {
            return -1;
        }
        if (first2.getPerimeter() < word2.getPerimeter()) {
            return 1;
        }
        return 0;
    }
}
