/*
 * Name: Umar Farooq
 * Email ID: umar.farooq.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    // bigger area first, then bigger perimeter first
    public int compare(Shape lhs2, Shape entry2) {
        double diff = entry2.getArea() - lhs2.getArea();
        if (diff == 0) {
            diff = entry2.getPerimeter() - lhs2.getPerimeter();
        }
        if (diff > 0) {
            return 1;
        } else if (diff < 0) {
            return -1;
        }
        return 0;
    }
}
