public class Test {
    public static void main(String[] args) {
        Shape c = new Circle(2.0)
        System.out.println(c.getArea());
    }
}
