/*
 * Name: Amelia Tan
 * Email ID: amelia.tan.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    public int compare(Shape a, Shape w) {
        int byArea = Double.compare(w.getArea(), a.getArea());
        if (byArea != 0) {
            return byArea;
        }
        return Double.compare(w.getPerimeter(), a.getPerimeter());
    }
}
