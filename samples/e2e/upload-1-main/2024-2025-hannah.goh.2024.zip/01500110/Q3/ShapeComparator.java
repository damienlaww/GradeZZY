/*
 * Name: Hannah Goh
 * Email ID: hannah.goh.2024@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    // bigger area first, then bigger perimeter first
    public int compare(Shape o1, Shape x) {
        double diff = x.getArea() - o1.getArea();
        if (diff == 0) {
            diff = x.getPerimeter() - o1.getPerimeter();
        }
        if (diff > 0) {
            return 1;
        } else if (diff < 0) {
            return -1;
        }
        return 0;
    }
}
