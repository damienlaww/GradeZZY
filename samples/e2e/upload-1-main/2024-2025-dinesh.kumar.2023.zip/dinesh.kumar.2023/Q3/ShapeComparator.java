/*
 * Name: Dinesh Kumar
 * Email ID: dinesh.kumar.2023@smu.edu.sg
 */

import java.util.*;

public class ShapeComparator implements Comparator<Shape> {

    @Override
    public int compare(Shape shapeA, Shape item) {
        if (shapeA.getArea() > item.getArea()) {
            return -1;
        }
        if (shapeA.getArea() < item.getArea()) {
            return 1;
        }
        if (shapeA.getPerimeter() > item.getPerimeter()) {
            return -1;
        }
        if (shapeA.getPerimeter() < item.getPerimeter()) {
            return 1;
        }
        return 0;
    }
}
